# RENTAL GABON CAR — icônes et logo

- `design/assets/` : icônes PNG prêtes pour Access, logo de voiture seul et logos complets en PNG/SVG.
- `design/outils/icones-svg/` : sources vectorielles des icônes de l’interface, avec leur licence ISC.
- `design/COULEURS.md` et `design/ICONES_LOGO.md` : palette et indications d’usage.

Logo blanc : à utiliser sur fond sombre. Logo bleu : à utiliser sur fond clair. Les deux PNG du logo complet sont transparents (920 × 144) ; les SVG sont redimensionnables sans perte.

Les photos et les maquettes ne sont pas incluses dans ce pack.
