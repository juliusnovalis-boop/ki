# RENTAL GABON CAR — icônes et logo

Dans `design/assets/` se trouvent les PNG prêts à importer dans Access, exportés avec les formes, couleurs et tailles natives de leur rôle dans les maquettes. Les variantes de couleur (état normal/actif, bouton, carte, indicateur) sont volontairement distinctes : voir `design/ICONES_LOGO.md`.

Le logo compact du menu est `logo-menu-blanc.png` (368 × 56 px, à afficher à 184 × 28 px). Les logos horizontaux standards blanc/bleu sont également fournis en PNG transparent et SVG.

Les photos et les maquettes complètes ne sont pas incluses. Les sources Lucide `currentColor` ne sont pas dans ce pack ; les PNG exportés sont ceux à utiliser pour obtenir l’apparence exacte des maquettes.
