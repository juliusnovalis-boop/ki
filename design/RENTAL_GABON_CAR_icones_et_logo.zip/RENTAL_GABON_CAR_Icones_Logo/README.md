# RENTAL GABON CAR — icônes et logo

- `design/assets/` : icônes PNG prêtes pour Access, pictogramme voiture et logos en PNG/SVG.
- `design/outils/icones-svg/` : sources vectorielles des icônes de l’interface, avec leur licence ISC.
- `design/COULEURS.md` et `design/ICONES_LOGO.md` : palette et indications d’usage.

Pour le menu bleu marine, `logo-menu-blanc.png` est le logo compact prévu pour un affichage à 184 × 28 px (4,87 × 0,74 cm) ; son fichier PNG fait 368 × 56 px pour rester net à cette taille. Les logos horizontaux standards blanc et bleu sont aussi disponibles en PNG transparent et en SVG.

Les photos et les maquettes ne sont pas incluses dans ce pack.
